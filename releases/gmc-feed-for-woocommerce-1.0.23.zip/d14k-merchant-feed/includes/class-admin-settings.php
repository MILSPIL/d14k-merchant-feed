<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class D14K_Admin_Settings {

    private $generator;
    private $wpml;
    private $cron;

    public function __construct( $generator, $wpml, $cron ) {
        $this->generator = $generator;
        $this->wpml      = $wpml;
        $this->cron      = $cron;

        add_action( 'admin_menu', array( $this, 'add_menu' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
        add_action( 'admin_bar_menu', array( $this, 'add_admin_bar_link' ), 100 );
        add_action( 'admin_post_d14k_save_settings', array( $this, 'save_settings' ) );
        add_action( 'admin_post_d14k_generate_now', array( $this, 'handle_generate_now' ) );
        add_action( 'admin_post_d14k_test_validation', array( $this, 'handle_test_validation' ) );
    }

    public function add_menu() {
        add_menu_page(
            'GMC Feed',
            'GMC Feed',
            'manage_woocommerce',
            'd14k-merchant-feed',
            array( $this, 'render_page' ),
            'dashicons-cloud-upload',
            56 // Position close to WooCommerce products often
        );
    }

    public function add_admin_bar_link( $admin_bar ) {
        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            return;
        }

        $admin_bar->add_node( array(
            'id'    => 'd14k-merchant-feed-bar',
            'title' => 'GMC Feed',
            'href'  => admin_url( 'admin.php?page=d14k-merchant-feed' ),
            'meta'  => array(
                'title' => 'Google Merchant Center Feed Settings',
            ),
        ) );
    }

    public function enqueue_assets( $hook ) {
        if ( strpos( $hook, 'd14k-merchant-feed' ) === false ) {
            return;
        }
        wp_enqueue_style( 'd14k-admin', D14K_FEED_URL . 'assets/admin.css', array(), D14K_FEED_VERSION );
    }

    public function render_page() {
        $settings  = get_option( 'd14k_feed_settings', $this->get_defaults() );
        $languages = $this->wpml->get_active_languages();
        $intervals = $this->cron->get_interval_options();
        $next_run  = $this->cron->get_next_run();
        $wc_cats          = get_terms( array( 'taxonomy' => 'product_cat', 'hide_empty' => false, 'orderby' => 'name' ) );
        $excluded_cat_ids = isset( $settings['excluded_categories'] ) ? array_map( 'intval', $settings['excluded_categories'] ) : array();
        // Build category hierarchy for tree rendering
        $cat_by_id    = array();
        $cat_children = array(); // parent_id => [child term_ids]
        if ( $wc_cats && ! is_wp_error( $wc_cats ) ) {
            foreach ( $wc_cats as $_cat ) {
                $cat_by_id[ $_cat->term_id ] = $_cat;
                $cat_children[ (int) $_cat->parent ][] = $_cat->term_id;
            }
        }
        $wc_attributes    = function_exists( 'wc_get_attribute_taxonomies' ) ? wc_get_attribute_taxonomies() : array();
        $attr_terms_data  = array();
        foreach ( $wc_attributes as $attr ) {
            $taxonomy = wc_attribute_taxonomy_name( $attr->attribute_name );
            $terms    = get_terms( array( 'taxonomy' => $taxonomy, 'hide_empty' => false ) );
            if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
                $attr_terms_data[ $taxonomy ] = array(
                    'label' => $attr->attribute_label,
                    'terms' => $terms,
                );
            }
        }
        $custom_rules   = isset( $settings['custom_rules'] ) ? $settings['custom_rules'] : array();
        $rule_fields    = array(
            'title'         => array( 'label' => 'Назва товару',       'type' => 'text' ),
            'sku'           => array( 'label' => 'SKU',                'type' => 'text' ),
            'regular_price' => array( 'label' => 'Ціна (звичайна)',    'type' => 'number' ),
            'sale_price'    => array( 'label' => 'Ціна зі знижкою',   'type' => 'number' ),
            'stock_status'  => array( 'label' => 'Статус наявності',  'type' => 'status' ),
            'tag'           => array( 'label' => 'Тег товару',         'type' => 'text' ),
            'custom_meta'   => array( 'label' => 'Власне поле (meta)', 'type' => 'meta' ),
        );
        $rule_conditions = array(
            'text'   => array( 'contains' => 'Містить', 'not_contains' => 'Не містить', 'equals' => 'Дорівнює', 'not_equals' => 'Не дорівнює', 'starts_with' => 'Починається з', 'ends_with' => 'Закінчується на', 'is_empty' => 'Порожнє', 'not_empty' => 'Не порожнє' ),
            'number' => array( 'equals' => '= Дорівнює', 'not_equals' => '≠ Не дорівнює', 'gt' => '> Більше ніж', 'lt' => '< Менше ніж', 'gte' => '≥ Більше або рівне', 'lte' => '≤ Менше або рівне', 'is_empty' => 'Не вказана', 'not_empty' => 'Вказана' ),
            'status' => array( 'equals' => 'Дорівнює', 'not_equals' => 'Не дорівнює' ),
            'meta'   => array( 'contains' => 'Містить', 'not_contains' => 'Не містить', 'equals' => 'Дорівнює', 'not_equals' => 'Не дорівнює', 'is_empty' => 'Порожнє', 'not_empty' => 'Не порожнє' ),
        );

        $notice    = isset( $_GET['d14k_notice'] ) ? sanitize_text_field( $_GET['d14k_notice'] ) : '';
        $show_validation = isset( $_GET['show_validation'] );

        ?>
        <div class="wrap d14k-wrap">
            <h1>D14K Merchant Feed</h1>

            <?php if ( $notice === 'saved' ) : ?>
                <div class="notice notice-success is-dismissible"><p>Налаштування збережено.</p></div>
            <?php elseif ( $notice === 'generated' ) : ?>
                <div class="notice notice-success is-dismissible"><p>Фіди успішно згенеровано!</p></div>
            <?php elseif ( $notice === 'error' ) : ?>
                <div class="notice notice-error is-dismissible"><p>Помилка генерації. Перевірте логи.</p></div>
            <?php endif; ?>

            <?php if ( $show_validation ) : ?>
                <?php $this->render_validation_results(); ?>
                <?php return; ?>
            <?php endif; ?>

            <div class="d14k-card">
                <h2>Фіди</h2>
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th>Мова</th>
                            <th>URL фіду</th>
                            <th>Останнє оновлення</th>
                            <th>Товарів</th>
                            <th>Помилки</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ( $languages as $lang ) :
                        $feed_url   = $this->generator->get_feed_url( $lang );
                        $last_gen   = get_option( "d14k_feed_last_generated_{$lang}", '—' );
                        $last_error = get_option( "d14k_feed_last_error_{$lang}", '' );
                        $last_stats = $this->generator->get_last_stats( $lang );
                        $count      = $last_stats ? $last_stats['valid'] : '—';
                        $skipped    = $last_stats ? $last_stats['skipped'] : 0;
                    ?>
                        <tr>
                            <td><strong><?php echo esc_html( strtoupper( $lang ) ); ?></strong></td>
                            <td>
                                <code id="feed-url-<?php echo esc_attr( $lang ); ?>"><?php echo esc_url( $feed_url ); ?></code>
                                <button type="button" class="button button-small d14k-copy" data-target="feed-url-<?php echo esc_attr( $lang ); ?>">Копіювати</button>
                            </td>
                            <td><?php echo esc_html( $last_gen ); ?></td>
                            <td><?php echo esc_html( $count ); ?><?php if ( $skipped ) : ?> <small>(пропущено: <?php echo (int) $skipped; ?>)</small><?php endif; ?></td>
                            <td><?php echo $last_error ? '<span class="d14k-error">' . esc_html( $last_error ) . '</span>' : '&#10003;'; ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>

                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top: 10px;">
                    <?php wp_nonce_field( 'd14k_generate_now' ); ?>
                    <input type="hidden" name="action" value="d14k_generate_now">
                    <button type="submit" class="button button-primary">Згенерувати зараз</button>
                    <?php if ( $next_run ) : ?>
                        <span class="d14k-next-run">Наступна автогенерація: <?php echo esc_html( $next_run ); ?></span>
                    <?php endif; ?>
                </form>

                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top: 10px;">
                    <?php wp_nonce_field( 'd14k_test_validation' ); ?>
                    <input type="hidden" name="action" value="d14k_test_validation">
                    <button type="submit" class="button">🔍 Тестова перевірка (10 товарів)</button>
                    <p class="description">Перевірте фід на наявність всіх обов'язкових полів перед відправкою до Google Merchant Center</p>
                </form>
            </div>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <?php wp_nonce_field( 'd14k_save_settings' ); ?>
                <input type="hidden" name="action" value="d14k_save_settings">

                <div class="d14k-card">
                    <h2>Налаштування</h2>
                    <table class="form-table">
                        <tr>
                            <th>Увімкнути фід</th>
                            <td>
                                <label>
                                    <input type="checkbox" name="enabled" value="1" <?php checked( ! empty( $settings['enabled'] ) ); ?>>
                                    Автоматична генерація за розкладом
                                </label>
                            </td>
                        </tr>
                        <tr>
                            <th>Інтервал оновлення</th>
                            <td>
                                <select name="cron_interval">
                                    <?php foreach ( $intervals as $key => $label ) : ?>
                                        <option value="<?php echo esc_attr( $key ); ?>" <?php selected( isset( $settings['cron_interval'] ) ? $settings['cron_interval'] : 'd14k_every_6_hours', $key ); ?>><?php echo esc_html( $label ); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th>Бренд</th>
                            <td>
                                <?php
                                $brand_mode      = isset( $settings['brand_mode'] ) ? $settings['brand_mode'] : 'custom';
                                $brand_attribute = isset( $settings['brand_attribute'] ) ? $settings['brand_attribute'] : '';
                                ?>
                                <fieldset style="border:none;padding:0;margin:0;">
                                    <label style="display:block;margin-bottom:8px;">
                                        <input type="radio" name="brand_mode" value="custom" class="d14k-brand-mode"
                                               <?php checked( $brand_mode, 'custom' ); ?>>
                                        <strong>Власний бренд</strong> — ввести назву вручну
                                    </label>
                                    <div id="d14k-brand-custom-wrap" style="margin:0 0 12px 22px;<?php echo $brand_mode !== 'custom' ? 'display:none;' : ''; ?>">
                                        <input type="text" name="brand"
                                               value="<?php echo esc_attr( isset( $settings['brand'] ) ? $settings['brand'] : '' ); ?>"
                                               class="regular-text" placeholder="Назва вашого бренду">
                                    </div>
                                    <label style="display:block;margin-bottom:8px;">
                                        <input type="radio" name="brand_mode" value="attribute" class="d14k-brand-mode"
                                               <?php checked( $brand_mode, 'attribute' ); ?>>
                                        <strong>З атрибуту товару</strong> — брати значення з атрибуту WooCommerce
                                    </label>
                                    <div id="d14k-brand-attr-wrap" style="margin:0 0 12px 22px;<?php echo $brand_mode !== 'attribute' ? 'display:none;' : ''; ?>">
                                        <select name="brand_attribute" style="min-width:240px;">
                                            <option value="">— оберіть атрибут —</option>
                                            <?php foreach ( $wc_attributes as $attr ) :
                                                $tax = wc_attribute_taxonomy_name( $attr->attribute_name );
                                            ?>
                                                <option value="<?php echo esc_attr( $tax ); ?>"
                                                        <?php selected( $brand_attribute, $tax ); ?>>
                                                    <?php echo esc_html( $attr->attribute_label ); ?>
                                                    (<?php echo esc_html( $tax ); ?>)
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <p class="description" style="margin:8px 0 4px;">Якщо атрибут відсутній у товарі — використовується запасний бренд:</p>
                                        <input type="text" name="brand_fallback"
                                               value="<?php echo esc_attr( isset( $settings['brand_fallback'] ) ? $settings['brand_fallback'] : '' ); ?>"
                                               class="regular-text" placeholder="Запасний бренд (якщо атрибут відсутній)">
                                    </div>
                                </fieldset>
                            </td>
                        </tr>
                        <tr>
                            <th>Країна походження<br><small>(Country of Origin)</small></th>
                            <td>
                                <select name="country_of_origin" class="regular-text">
                                    <?php
                                    $selected_country = isset( $settings['country_of_origin'] ) ? $settings['country_of_origin'] : '';
                                    $countries = array(
                                        ''   => '— не вказувати —',
                                        'UA' => 'Україна (Ukraine)',
                                        'IT' => 'Італія (Italy)',
                                        'TR' => 'Туреччина (Turkey)',
                                        'IN' => 'Індія (India)',
                                        'CN' => 'Китай (China)',
                                        'US' => 'США (United States)',
                                        'DE' => 'Німеччина (Germany)',
                                        'FR' => 'Франція (France)',
                                        'GB' => 'Велика Британія (United Kingdom)',
                                        'PL' => 'Польща (Poland)',
                                    );
                                    foreach ( $countries as $code => $name ) :
                                    ?>
                                        <option value="<?php echo esc_attr( $code ); ?>" <?php selected( $selected_country, $code ); ?>><?php echo esc_html( $name ); ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="description">Якщо вибрано «не вказувати» — тег <code>country_of_origin</code> не додається у фід.</p>
                            </td>
                        </tr>
                        <tr>
                            <th>Google Product Category<br><small>(за замовчуванням)</small></th>
                            <td><input type="text" name="default_google_category" value="<?php echo esc_attr( isset( $settings['default_google_category'] ) ? $settings['default_google_category'] : '' ); ?>" class="large-text" placeholder="Apparel &amp; Accessories &gt; Jewelry"></td>
                        </tr>
                    </table>
                </div>

                <div class="d14k-card">
                    <h2>Маппінг категорій Google</h2>
                    <p>Призначте Google Product Category для кожної категорії WooCommerce. Порожнє = використовується категорія за замовчуванням.</p>
                    <table class="widefat striped">
                        <thead>
                            <tr>
                                <th>Категорія WooCommerce</th>
                                <th>Google Product Category</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                        $cat_map = isset( $settings['category_map'] ) ? $settings['category_map'] : array();
                        if ( $wc_cats && ! is_wp_error( $wc_cats ) ) :
                            foreach ( $wc_cats as $cat ) :
                                if ( ! $cat->count ) { continue; } // skip empty categories in mapping
                        ?>
                            <tr>
                                <td><?php echo esc_html( $cat->name ); ?> <small>(<?php echo (int) $cat->count; ?> товарів)</small></td>
                                <td>
                                    <input type="text"
                                           name="category_map[<?php echo (int) $cat->term_id; ?>]"
                                           value="<?php echo esc_attr( isset( $cat_map[ $cat->term_id ] ) ? $cat_map[ $cat->term_id ] : '' ); ?>"
                                           class="large-text"
                                           placeholder="Apparel &amp; Accessories &gt; Jewelry &gt; ...">
                                </td>
                            </tr>
                        <?php
                            endforeach;
                        endif;
                        ?>
                        </tbody>
                    </table>
                </div>

                <div class="d14k-card" style="margin-top:0;">
                    <h2>Виключені категорії</h2>
                    <p>Позначені категорії <strong>не потраплять у фід</strong>. При позначенні батьківської категорії — всі підкатегорії позначаються автоматично (але можна зняти окремо).</p>
                    <?php if ( empty( $cat_by_id ) ) : ?>
                        <p class="description">Категорії не знайдені.</p>
                    <?php else : ?>
                        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:0 30px;">
                            <?php echo $this->render_cat_tree_html( $cat_children, $cat_by_id, $excluded_cat_ids, 0, 0 ); ?>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="d14k-card" style="margin-top:0;">
                    <h2>Фільтрація за атрибутами</h2>
                    <p>Активуйте фільтр для атрибута та вкажіть значення. Якщо фільтр не увімкнено — всі значення потрапляють у фід.</p>
                    <?php if ( empty( $attr_terms_data ) ) : ?>
                        <p class="description">Атрибути товарів не знайдені.</p>
                    <?php else : ?>
                        <?php foreach ( $attr_terms_data as $taxonomy => $attr_data ) :
                            $af         = isset( $settings['attribute_filters'][ $taxonomy ] ) ? $settings['attribute_filters'][ $taxonomy ] : array();
                            $af_enabled = ! empty( $af['enabled'] );
                            $af_mode    = isset( $af['mode'] ) ? $af['mode'] : 'exclude';
                            $af_values  = isset( $af['values'] ) ? (array) $af['values'] : array();
                        ?>
                            <div class="d14k-attr-filter-block" style="border:1px solid #ddd;border-radius:4px;padding:15px;margin-bottom:15px;">
                                <h4 style="margin:0 0 10px;">
                                    <label>
                                        <input type="checkbox"
                                               name="attr_filter_enabled[<?php echo esc_attr( $taxonomy ); ?>]"
                                               value="1"
                                               class="d14k-attr-enable"
                                               <?php checked( $af_enabled ); ?>>
                                        <strong><?php echo esc_html( $attr_data['label'] ); ?></strong>
                                        <small style="color:#888;font-weight:normal;">&nbsp;(<?php echo esc_html( $taxonomy ); ?>)</small>
                                    </label>
                                </h4>
                                <div class="d14k-attr-filter-body"<?php echo $af_enabled ? '' : ' style="display:none;"'; ?>>
                                    <p style="margin:0 0 10px;">
                                        <label style="margin-right:20px;">
                                            <input type="radio"
                                                   name="attr_filter_mode[<?php echo esc_attr( $taxonomy ); ?>]"
                                                   value="exclude"
                                                   <?php checked( $af_mode, 'exclude' ); ?>>
                                            Виключити товари з цими значеннями
                                        </label>
                                        <label>
                                            <input type="radio"
                                                   name="attr_filter_mode[<?php echo esc_attr( $taxonomy ); ?>]"
                                                   value="include"
                                                   <?php checked( $af_mode, 'include' ); ?>>
                                            Включити тільки товари з цими значеннями
                                        </label>
                                    </p>
                                    <div style="columns:3;column-gap:20px;">
                                        <?php foreach ( $attr_data['terms'] as $term ) : ?>
                                            <label style="display:block;margin-bottom:5px;">
                                                <input type="checkbox"
                                                       name="attr_filter_values[<?php echo esc_attr( $taxonomy ); ?>][]"
                                                       value="<?php echo esc_attr( $term->slug ); ?>"
                                                       <?php checked( in_array( $term->slug, $af_values, true ) ); ?>>
                                                <?php echo esc_html( $term->name ); ?>
                                            </label>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>

                <div class="d14k-card" style="margin-top:0;">
                    <h2>Розширені правила фільтрації</h2>
                    <p>Додайте правила для тонкого керування фідом. <strong>Виключити</strong> — товар прибирається з фіду, якщо умова виконується. <strong>Включити тільки</strong> — товар потрапляє у фід лише якщо умова виконується (whitelist).</p>
                    <table class="widefat" id="d14k-rules-table" style="table-layout:auto;">
                        <thead>
                            <tr>
                                <th>Поле</th>
                                <th>Ключ (meta)</th>
                                <th>Умова</th>
                                <th>Значення</th>
                                <th>Дія</th>
                                <th style="width:60px;"></th>
                            </tr>
                        </thead>
                        <tbody id="d14k-rules-body">
                        <?php foreach ( $custom_rules as $ridx => $rule ) :
                            $r_field   = isset( $rule['field'] ) && isset( $rule_fields[ $rule['field'] ] ) ? $rule['field'] : 'title';
                            $r_mk      = isset( $rule['meta_key'] ) ? $rule['meta_key'] : '';
                            $r_cond    = isset( $rule['condition'] ) ? $rule['condition'] : 'contains';
                            $r_val     = isset( $rule['value'] ) ? $rule['value'] : '';
                            $r_action  = isset( $rule['action'] ) ? $rule['action'] : 'exclude';
                            $r_ftype   = $rule_fields[ $r_field ]['type'];
                            $r_conds   = $rule_conditions[ $r_ftype ];
                            $r_no_val  = in_array( $r_cond, array( 'is_empty', 'not_empty' ), true );
                        ?>
                            <tr class="d14k-rule-row">
                                <td>
                                    <select name="custom_rules[<?php echo (int) $ridx; ?>][field]" class="d14k-rule-field" style="width:auto;">
                                        <?php foreach ( $rule_fields as $fk => $fd ) : ?>
                                            <option value="<?php echo esc_attr( $fk ); ?>" <?php selected( $r_field, $fk ); ?>><?php echo esc_html( $fd['label'] ); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                                <td>
                                    <input type="text" name="custom_rules[<?php echo (int) $ridx; ?>][meta_key]" class="d14k-rule-meta-key" value="<?php echo esc_attr( $r_mk ); ?>" placeholder="напр. _weight" style="width:110px;<?php echo $r_ftype !== 'meta' ? 'display:none;' : ''; ?>">
                                </td>
                                <td>
                                    <select name="custom_rules[<?php echo (int) $ridx; ?>][condition]" class="d14k-rule-condition" style="width:auto;">
                                        <?php foreach ( $r_conds as $ck => $cl ) : ?>
                                            <option value="<?php echo esc_attr( $ck ); ?>" <?php selected( $r_cond, $ck ); ?>><?php echo esc_html( $cl ); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                                <td>
                                    <?php if ( $r_ftype === 'status' ) : ?>
                                        <select name="custom_rules[<?php echo (int) $ridx; ?>][value]" class="d14k-rule-value" style="width:auto;<?php echo $r_no_val ? 'display:none;' : ''; ?>">
                                            <option value="instock"    <?php selected( $r_val, 'instock' ); ?>>В наявності</option>
                                            <option value="outofstock" <?php selected( $r_val, 'outofstock' ); ?>>Немає в наявності</option>
                                            <option value="onbackorder"<?php selected( $r_val, 'onbackorder' ); ?>>Під замовлення</option>
                                        </select>
                                    <?php else : ?>
                                        <input type="<?php echo $r_ftype === 'number' ? 'number' : 'text'; ?>"
                                               name="custom_rules[<?php echo (int) $ridx; ?>][value]"
                                               class="d14k-rule-value"
                                               value="<?php echo esc_attr( $r_val ); ?>"
                                               placeholder="Значення"
                                               style="width:130px;<?php echo $r_no_val ? 'display:none;' : ''; ?>">
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <select name="custom_rules[<?php echo (int) $ridx; ?>][action]" style="width:auto;">
                                        <option value="exclude" <?php selected( $r_action, 'exclude' ); ?>>Виключити</option>
                                        <option value="include" <?php selected( $r_action, 'include' ); ?>>Включити тільки</option>
                                    </select>
                                </td>
                                <td><button type="button" class="button d14k-remove-rule">✕</button></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    <p style="margin-top:10px;">
                        <button type="button" class="button" id="d14k-add-rule">+ Додати правило</button>
                    </p>
                </div>

                <p class="submit">
                    <button type="submit" class="button button-primary">Зберегти налаштування</button>
                </p>
            </form>
        </div>

        <script>
        document.querySelectorAll('.d14k-copy').forEach(function(btn) {
            btn.addEventListener('click', function() {
                var el = document.getElementById(this.dataset.target);
                navigator.clipboard.writeText(el.textContent).then(function() {
                    btn.textContent = 'Скопійовано!';
                    setTimeout(function() { btn.textContent = 'Копіювати'; }, 1500);
                });
            });
        });

        // ---- Brand mode toggle ----
        document.querySelectorAll('.d14k-brand-mode').forEach(function(radio) {
            radio.addEventListener('change', function() {
                document.getElementById('d14k-brand-custom-wrap').style.display = this.value === 'custom'    ? '' : 'none';
                document.getElementById('d14k-brand-attr-wrap').style.display   = this.value === 'attribute' ? '' : 'none';
            });
        });

        // ---- Category exclusion cascade ----
        var d14kCatCbs = Array.from(document.querySelectorAll('.d14k-cat-cb'));
        function d14kGetCatDescendants(parentId) {
            var result = [];
            d14kCatCbs.forEach(function(cb) {
                if (parseInt(cb.dataset.parent, 10) === parentId) {
                    result.push(cb);
                    d14kGetCatDescendants(parseInt(cb.dataset.id, 10)).forEach(function(d) { result.push(d); });
                }
            });
            return result;
        }
        d14kCatCbs.forEach(function(cb) {
            cb.addEventListener('change', function() {
                d14kGetCatDescendants(parseInt(this.dataset.id, 10)).forEach(function(child) {
                    child.checked = cb.checked;
                });
            });
        });

        document.querySelectorAll('.d14k-attr-enable').forEach(function(cb) {
            cb.addEventListener('change', function() {
                var body = this.closest('.d14k-attr-filter-block').querySelector('.d14k-attr-filter-body');
                body.style.display = this.checked ? '' : 'none';
            });
        });

        // ---- Розширені правила фільтрації ----
        var d14kRuleFieldsData = <?php
            $jfields = array();
            foreach ( $rule_fields as $k => $v ) { $jfields[] = array( 'value' => $k, 'label' => $v['label'], 'type' => $v['type'] ); }
            echo json_encode( $jfields );
        ?>;
        var d14kCondsByType = <?php echo json_encode( $rule_conditions ); ?>;
        var d14kStatusVals  = [{v:'instock',l:'В наявності'},{v:'outofstock',l:'Немає в наявності'},{v:'onbackorder',l:'Під замовлення'}];
        var d14kNoValConds  = ['is_empty','not_empty'];
        var d14kRuleIdx     = <?php echo count( $custom_rules ); ?>;

        function d14kEsc(s) {
            return String(s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
        }
        function d14kFieldType(fval) {
            var f = d14kRuleFieldsData.find(function(x){return x.value===fval;});
            return f ? f.type : 'text';
        }
        function d14kBuildCondSelect(idx, ftype, selCond) {
            var conds = d14kCondsByType[ftype] || d14kCondsByType['text'];
            var h = '<select name="custom_rules['+idx+'][condition]" class="d14k-rule-condition" style="width:auto;">';
            Object.keys(conds).forEach(function(k){ h += '<option value="'+k+'"'+(k===selCond?' selected':'')+'>'+conds[k]+'</option>'; });
            return h + '</select>';
        }
        function d14kBuildValInput(idx, ftype, cond, val) {
            var hide = d14kNoValConds.indexOf(cond) !== -1 ? 'display:none;' : '';
            if (ftype === 'status') {
                var h = '<select name="custom_rules['+idx+'][value]" class="d14k-rule-value" style="width:auto;'+hide+'">';
                d14kStatusVals.forEach(function(s){ h += '<option value="'+s.v+'"'+(s.v===val?' selected':'')+'>'+s.l+'</option>'; });
                return h + '</select>';
            }
            var itype = ftype === 'number' ? 'number' : 'text';
            return '<input type="'+itype+'" name="custom_rules['+idx+'][value]" class="d14k-rule-value" value="'+d14kEsc(val)+'" placeholder="Значення" style="width:130px;'+hide+'">';
        }
        function d14kCreateRow(idx, saved) {
            saved = saved || {};
            var field  = saved.field     || 'title';
            var mk     = saved.meta_key  || '';
            var cond   = saved.condition || 'contains';
            var val    = saved.value     || '';
            var action = saved.action    || 'exclude';
            var ftype  = d14kFieldType(field);
            var fsHtml = '<select name="custom_rules['+idx+'][field]" class="d14k-rule-field" style="width:auto;">';
            d14kRuleFieldsData.forEach(function(f){ fsHtml += '<option value="'+f.value+'"'+(f.value===field?' selected':'')+'>'+f.label+'</option>'; });
            fsHtml += '</select>';
            var tr = document.createElement('tr');
            tr.className = 'd14k-rule-row';
            tr.innerHTML =
                '<td>'+fsHtml+'</td>'+
                '<td><input type="text" name="custom_rules['+idx+'][meta_key]" class="d14k-rule-meta-key" value="'+d14kEsc(mk)+'" placeholder="напр. _weight" style="width:110px;'+(ftype!=='meta'?'display:none;':'')+'"></td>'+
                '<td>'+d14kBuildCondSelect(idx,ftype,cond)+'</td>'+
                '<td>'+d14kBuildValInput(idx,ftype,cond,val)+'</td>'+
                '<td><select name="custom_rules['+idx+'][action]" style="width:auto;"><option value="exclude"'+(action==='exclude'?' selected':'')+'>Виключити</option><option value="include"'+(action==='include'?' selected':'')+'>Включити тільки</option></select></td>'+
                '<td><button type="button" class="button d14k-remove-rule">✕</button></td>';
            d14kInitRow(tr);
            return tr;
        }
        function d14kRebuildCondSelect(row, field, keepCond) {
            var ftype = d14kFieldType(field);
            var conds = d14kCondsByType[ftype] || d14kCondsByType['text'];
            var sel = row.querySelector('.d14k-rule-condition');
            var prev = keepCond || sel.value;
            sel.innerHTML = '';
            Object.keys(conds).forEach(function(k){
                var o = document.createElement('option');
                o.value = k; o.textContent = conds[k];
                if (k === prev) o.selected = true;
                sel.appendChild(o);
            });
        }
        function d14kRebuildValInput(row, ftype, cond) {
            var valCell = row.querySelector('.d14k-rule-value').closest('td');
            var oldVal  = row.querySelector('.d14k-rule-value').value || '';
            var m = row.querySelector('[name*="[field]"]').name.match(/\[(\d+)\]/);
            var idx = m ? m[1] : 0;
            valCell.innerHTML = d14kBuildValInput(idx, ftype, cond, oldVal);
        }
        function d14kInitRow(row) {
            var fs  = row.querySelector('.d14k-rule-field');
            var cs  = row.querySelector('.d14k-rule-condition');
            var mk  = row.querySelector('.d14k-rule-meta-key');
            var rm  = row.querySelector('.d14k-remove-rule');
            fs.addEventListener('change', function() {
                var ftype = d14kFieldType(this.value);
                if (mk) mk.style.display = ftype === 'meta' ? '' : 'none';
                d14kRebuildCondSelect(row, this.value, null);
                d14kRebuildValInput(row, ftype, cs.value);
            });
            cs.addEventListener('change', function() {
                d14kRebuildValInput(row, d14kFieldType(fs.value), this.value);
            });
            rm.addEventListener('click', function() { row.parentNode.removeChild(row); });
        }
        document.querySelectorAll('.d14k-rule-row').forEach(function(r){ d14kInitRow(r); });
        document.getElementById('d14k-add-rule').addEventListener('click', function() {
            document.getElementById('d14k-rules-body').appendChild(d14kCreateRow(d14kRuleIdx++));
        });
        </script>
        <?php
    }

    public function save_settings() {
        check_admin_referer( 'd14k_save_settings' );

        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( 'Access denied' );
        }

        $allowed_fields     = array( 'title', 'sku', 'regular_price', 'sale_price', 'stock_status', 'tag', 'custom_meta' );
        $allowed_conditions = array( 'equals', 'not_equals', 'contains', 'not_contains', 'starts_with', 'ends_with', 'gt', 'lt', 'gte', 'lte', 'is_empty', 'not_empty' );
        $custom_rules       = array();
        if ( ! empty( $_POST['custom_rules'] ) && is_array( $_POST['custom_rules'] ) ) {
            foreach ( $_POST['custom_rules'] as $rule ) {
                if ( ! is_array( $rule ) ) { continue; }
                $r_field = isset( $rule['field'] ) && in_array( $rule['field'], $allowed_fields, true ) ? $rule['field'] : '';
                if ( ! $r_field ) { continue; }
                $custom_rules[] = array(
                    'field'     => $r_field,
                    'meta_key'  => isset( $rule['meta_key'] ) ? sanitize_key( $rule['meta_key'] ) : '',
                    'condition' => isset( $rule['condition'] ) && in_array( $rule['condition'], $allowed_conditions, true ) ? $rule['condition'] : 'equals',
                    'value'     => isset( $rule['value'] ) ? sanitize_text_field( $rule['value'] ) : '',
                    'action'    => isset( $rule['action'] ) && $rule['action'] === 'include' ? 'include' : 'exclude',
                );
            }
        }

        $excluded_cats     = ! empty( $_POST['excluded_categories'] ) && is_array( $_POST['excluded_categories'] )
            ? array_map( 'intval', $_POST['excluded_categories'] )
            : array();
        $attribute_filters = array();
        $enabled_attrs     = ! empty( $_POST['attr_filter_enabled'] ) ? (array) $_POST['attr_filter_enabled'] : array();
        $filter_modes      = ! empty( $_POST['attr_filter_mode'] ) ? (array) $_POST['attr_filter_mode'] : array();
        $filter_values     = ! empty( $_POST['attr_filter_values'] ) ? (array) $_POST['attr_filter_values'] : array();
        foreach ( $enabled_attrs as $taxonomy => $v ) {
            $taxonomy = sanitize_key( $taxonomy );
            $mode     = isset( $filter_modes[ $taxonomy ] ) && $filter_modes[ $taxonomy ] === 'include' ? 'include' : 'exclude';
            $values   = isset( $filter_values[ $taxonomy ] ) ? array_map( 'sanitize_text_field', (array) $filter_values[ $taxonomy ] ) : array();
            $attribute_filters[ $taxonomy ] = array(
                'enabled' => true,
                'mode'    => $mode,
                'values'  => $values,
            );
        }

        $settings = array(
            'enabled'                 => ! empty( $_POST['enabled'] ),
            'cron_interval'           => sanitize_text_field( isset( $_POST['cron_interval'] ) ? $_POST['cron_interval'] : 'd14k_every_6_hours' ),
            'brand_mode'              => isset( $_POST['brand_mode'] ) && $_POST['brand_mode'] === 'attribute' ? 'attribute' : 'custom',
            'brand'                   => sanitize_text_field( isset( $_POST['brand'] ) ? $_POST['brand'] : '' ),
            'brand_attribute'         => sanitize_key( isset( $_POST['brand_attribute'] ) ? $_POST['brand_attribute'] : '' ),
            'brand_fallback'          => sanitize_text_field( isset( $_POST['brand_fallback'] ) ? $_POST['brand_fallback'] : '' ),
            'country_of_origin'       => sanitize_text_field( isset( $_POST['country_of_origin'] ) ? $_POST['country_of_origin'] : 'UA' ),
            'default_google_category' => sanitize_text_field( isset( $_POST['default_google_category'] ) ? $_POST['default_google_category'] : '' ),
            'category_map'            => array_map( 'sanitize_text_field', isset( $_POST['category_map'] ) ? $_POST['category_map'] : array() ),
            'excluded_categories'     => $excluded_cats,
            'attribute_filters'       => $attribute_filters,
            'custom_rules'            => $custom_rules,
        );

        $old_settings = get_option( 'd14k_feed_settings', array() );
        update_option( 'd14k_feed_settings', $settings );

        $old_interval = isset( $old_settings['cron_interval'] ) ? $old_settings['cron_interval'] : '';
        if ( $old_interval !== $settings['cron_interval'] ) {
            $this->cron->reschedule( $settings['cron_interval'] );
        }

        wp_redirect( admin_url( 'admin.php?page=d14k-merchant-feed&d14k_notice=saved' ) );
        exit;
    }

    public function handle_generate_now() {
        check_admin_referer( 'd14k_generate_now' );

        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( 'Access denied' );
        }

        $languages = $this->wpml->get_active_languages();
        $success   = true;

        foreach ( $languages as $lang ) {
            if ( ! $this->generator->generate( $lang ) ) {
                $success = false;
            }
        }

        $notice = $success ? 'generated' : 'error';
        wp_redirect( admin_url( "admin.php?page=d14k-merchant-feed&d14k_notice={$notice}" ) );
        exit;
    }

    public function handle_test_validation() {
        check_admin_referer( 'd14k_test_validation' );

        if ( ! current_user_can( 'manage_woocommerce' ) ) {
            wp_die( 'Access denied' );
        }

        $settings = get_option( 'd14k_feed_settings', $this->get_defaults() );
        $validator = new D14K_Feed_Validator();
        $report = $validator->validate_test_feed( $this->wpml, $settings, $this->generator );

        // Store report in transient for display
        set_transient( 'd14k_validation_report', $report, 300 ); // 5 minutes

        wp_redirect( admin_url( 'admin.php?page=d14k-merchant-feed&show_validation=1' ) );
        exit;
    }

    private function render_validation_results() {
        $report = get_transient( 'd14k_validation_report' );
        if ( ! $report ) {
            echo '<div class="notice notice-error"><p>Звіт валідації не знайдено. Спробуйте ще раз.</p></div>';
            return;
        }

        $total = $report['total_products'];
        $valid = $report['valid_products'];
        $invalid = $report['invalid_products'];
        $percentage = $total > 0 ? round( ( $valid / $total ) * 100 ) : 0;

        ?>
        <div class="d14k-card">
            <h2>🔍 Результати тестової валідації</h2>
            
            <div style="background: #f0f0f1; padding: 15px; border-radius: 4px; margin-bottom: 20px;">
                <h3 style="margin-top: 0;">Загальна статистика</h3>
                <p style="font-size: 16px; margin: 10px 0;">
                    <strong>Перевірено товарів:</strong> <?php echo (int) $total; ?><br>
                    <strong style="color: #46b450;">✅ Валідних:</strong> <?php echo (int) $valid; ?> (<?php echo (int) $percentage; ?>%)<br>
                    <strong style="color: #dc3232;">❌ З помилками:</strong> <?php echo (int) $invalid; ?> (<?php echo (int) ( 100 - $percentage ); ?>%)
                </p>
            </div>

            <?php if ( ! empty( $report['sample_item_xml'] ) ) : ?>
            <div style="margin-bottom: 30px;">
                <h3>📦 Приклад даних (XML)</h3>
                <p class="description" style="margin-bottom: 10px;">Так виглядатиме перший пройдений товар у файлі фіда. Перевірте теги та атрибути.</p>
                <textarea readonly style="width: 100%; height: 300px; font-family: monospace; font-size: 12px; background: #282c34; color: #abb2bf; border-radius: 4px; border: 1px solid #ccc; padding: 10px; box-sizing: border-box; white-space: pre;"><?php echo esc_textarea( $report['sample_item_xml'] ); ?></textarea>
            </div>
            <?php endif; ?>

            <h3>Статистика по полях</h3>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>Поле</th>
                        <th>Присутнє</th>
                        <th>Відсутнє</th>
                        <th>Статус</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ( $report['fields_stats'] as $field => $stats ) : 
                    $present = $stats['present'];
                    $missing = $stats['missing'];
                    $is_ok = $missing === 0;
                    $status_color = $is_ok ? '#46b450' : '#dc3232';
                    $status_icon = $is_ok ? '✅' : '⚠️';
                ?>
                    <tr>
                        <td><strong><?php echo esc_html( $stats['label'] ); ?></strong></td>
                        <td><?php echo (int) $present; ?>/<?php echo (int) $total; ?></td>
                        <td style="color: <?php echo $missing > 0 ? '#dc3232' : '#666'; ?>;"><?php echo (int) $missing; ?></td>
                        <td style="color: <?php echo esc_attr( $status_color ); ?>; font-size: 18px;"><?php echo $status_icon; ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <h3 style="margin-top: 30px;">Детальний список товарів</h3>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Назва товару</th>
                        <th>Статус</th>
                        <th>Відсутні поля</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ( $report['products'] as $product ) : 
                    $status_color = $product['is_valid'] ? '#46b450' : '#dc3232';
                    $status_text = $product['is_valid'] ? '✅ Валідний' : '❌ Помилки';
                ?>
                    <tr>
                        <td><?php echo (int) $product['id']; ?></td>
                        <td><?php echo esc_html( $product['title'] ); ?></td>
                        <td style="color: <?php echo esc_attr( $status_color ); ?>; font-weight: bold;"><?php echo $status_text; ?></td>
                        <td>
                            <?php if ( ! empty( $product['missing_fields'] ) ) : ?>
                                <span style="color: #dc3232;">
                                    <?php echo esc_html( implode( ', ', $product['missing_fields'] ) ); ?>
                                </span>
                            <?php else : ?>
                                <span style="color: #46b450;">Всі поля присутні</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <p style="margin-top: 20px;">
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=d14k-merchant-feed' ) ); ?>" class="button">← Повернутися до налаштувань</a>
            </p>
        </div>
        <?php
    }

    /**
     * Recursively renders a hierarchical checkbox tree for category exclusion.
     *
     * @param array $children_map  parent_id => [child term_ids]
     * @param array $cat_by_id     term_id => WP_Term
     * @param array $excluded_ids  currently excluded term IDs
     * @param int   $parent_id     start rendering from this parent
     * @param int   $depth         current nesting depth (for indentation)
     * @return string HTML
     */
    private function render_cat_tree_html( $children_map, $cat_by_id, $excluded_ids, $parent_id, $depth ) {
        if ( empty( $children_map[ $parent_id ] ) ) {
            return '';
        }
        $html    = '';
        $indent  = $depth * 18; // px left padding per level
        foreach ( $children_map[ $parent_id ] as $term_id ) {
            if ( ! isset( $cat_by_id[ $term_id ] ) ) {
                continue;
            }
            $cat         = $cat_by_id[ $term_id ];
            $checked     = in_array( (int) $term_id, $excluded_ids, true ) ? ' checked' : '';
            $has_kids    = ! empty( $children_map[ $term_id ] );
            $count_label = $cat->count ? ' <small style="color:#999;">(' . (int) $cat->count . ')</small>' : '';
            $arrow       = $has_kids ? ' <span style="color:#aaa;font-size:10px;">▸</span>' : '';

            $html .= '<div style="break-inside:avoid;padding-left:' . $indent . 'px;margin-bottom:5px;">';
            $html .= '<label>';
            $html .= '<input type="checkbox"'
                   . ' name="excluded_categories[]"'
                   . ' value="' . (int) $term_id . '"'
                   . ' class="d14k-cat-cb"'
                   . ' data-id="' . (int) $term_id . '"'
                   . ' data-parent="' . (int) $cat->parent . '"'
                   . $checked . '> ';
            $html .= esc_html( $cat->name ) . $count_label . $arrow;
            $html .= '</label>';
            $html .= '</div>';

            // Render children recursively
            $html .= $this->render_cat_tree_html( $children_map, $cat_by_id, $excluded_ids, $term_id, $depth + 1 );
        }
        return $html;
    }

    private function get_defaults() {
        return array(
            'enabled'                 => true,
            'cron_interval'           => 'd14k_every_6_hours',
            'brand_mode'              => 'custom',
            'brand'                   => '',
            'brand_attribute'         => '',
            'brand_fallback'          => '',
            'country_of_origin'       => '',
            'default_google_category' => '',
            'category_map'            => array(),
            'excluded_categories'     => array(),
            'attribute_filters'       => array(),
            'custom_rules'            => array(),
        );
    }
}
